/*
ideaPlanner.controller('RouteCtrl', [function($scope, $routeParams) {
    var ref = new Firebase("https://sizzling-torch-8958.firebaseio.com");

    //Clears database on initiation.
    ref.remove();

    // sessionID stores the unique value created on initial push. Used for referencing a users session.
    var sessionID = ref.push({'user': 'user'}).key();
console.log(sessionID);



    $scope.cool = $routeParams.fullpage;

}]);
*/
